package com.example.mi.dao;

import com.example.mi.Entity.UserRecord;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Date;
import java.util.List;

public interface UserRecordRepository extends JpaRepository<UserRecord, Long> {
    List<UserRecord> findUserRecordsByDateAfterAndDateBeforeAndEmailId(Date d, Date d2, String emailId);
    UserRecord findUserRecordByDateAfterAndDateBefore(Date d, Date d2);
}
