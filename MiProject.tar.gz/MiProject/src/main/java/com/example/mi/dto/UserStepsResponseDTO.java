package com.example.mi.dto;

import java.util.Date;

public class UserStepsResponseDTO {
    private Date date;
    private String steps;

    public String getSteps() {
        return steps;
    }

    public void setSteps(String steps) {
        this.steps = steps;
    }
}
