package com.example.mi.Service.ServiceImpl;

import com.example.mi.Entity.UserLogin;
import com.example.mi.Service.UserLoginService;
import com.example.mi.dao.UserLoginRepository;
import com.example.mi.dto.UserLoginRequestDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserLoginServiceImpl implements UserLoginService {

    @Autowired
    UserLoginRepository userLoginRepository;

    @Override
    public String authenticate(UserLoginRequestDTO userLoginRequestDTO) {
        UserLogin user = userLoginRepository.findByEmailIdAndPassword
                (userLoginRequestDTO.getEmailId(),
                userLoginRequestDTO.getPassword());
        System.out.println("USer : "+user);
        if(user != null){
            return "login successed";
        }
        return null;
    }
}
