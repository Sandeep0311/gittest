package com.example.mi.Controller;


import com.example.mi.Common.GenericResponseDTO;
import com.example.mi.Service.UserLoginService;
import com.example.mi.dto.UserLoginRequestDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class UserLoginController {
    @Autowired
    UserLoginService userLoginService;

@RequestMapping(value = "/api/login", method = RequestMethod.POST)
    public @ResponseBody GenericResponseDTO<String> login(@RequestBody UserLoginRequestDTO userLoginRequestDTO){
    String token = userLoginService.authenticate(userLoginRequestDTO);
    GenericResponseDTO responseDTO = new GenericResponseDTO();
    if(token == null) {
        responseDTO.setStatus("false");
        responseDTO.setMessage("Invalid Username or Password");
    }else{
        responseDTO.setStatus("true");
        responseDTO.setMessage("Login Success");
        responseDTO.setData(null);
    }
    return responseDTO;
}

    @RequestMapping(value={"/", "/login"}, method = RequestMethod.GET)
    public ModelAndView login(){
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("login");
        return modelAndView;
    }

}
