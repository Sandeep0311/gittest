package com.example.mi.Service;

import com.example.mi.dto.UserLoginRequestDTO;

public interface UserLoginService {

    String authenticate(UserLoginRequestDTO userLoginRequestDTO);
}
